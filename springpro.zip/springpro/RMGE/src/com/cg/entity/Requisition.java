package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="requisitions")
public class Requisition {
@Id
private String requisitionId;
private String rmId;
private String projectId;
private String startDate;
private String closingDate;
private String currentStatus;
private String vacancyName;
private String skill;
private String domain;
private int numberRequired;
public String getRequisitionId() {
	return requisitionId;
}
public void setRequisitionId(String requisitionId) {
	this.requisitionId = requisitionId;
}
public String getRmId() {
	return rmId;
}
public void setRmId(String rmId) {
	this.rmId = rmId;
}
public String getProjectId() {
	return projectId;
}
public void setProjectId(String projectId) {
	this.projectId = projectId;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getClosingDate() {
	return closingDate;
}
public void setClosingDate(String closingDate) {
	this.closingDate = closingDate;
}
public String getCurrentStatus() {
	return currentStatus;
}
public void setCurrentStatus(String currentStatus) {
	this.currentStatus = currentStatus;
}
public String getVacancyName() {
	return vacancyName;
}
public void setVacancyName(String vacancyName) {
	this.vacancyName = vacancyName;
}
public String getSkill() {
	return skill;
}
public void setSkill(String skill) {
	this.skill = skill;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
public int getNumberRequired() {
	return numberRequired;
}
public void setNumberRequired(int numberRequired) {
	this.numberRequired = numberRequired;
}


}