package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.RmgeDao;
import com.cg.entity.EmployeeBean;
import com.cg.entity.ReqEmployee;
import com.cg.entity.Requisition;
@Service
@Transactional
public class RmgeServiceImpl implements RmgeSevice{
	@Autowired
private RmgeDao dao;

	@Override
	public List<EmployeeBean> getDetails(Requisition req,EmployeeBean emp) {
		
		return dao.getDetails(req,emp);
	}

	@Override
	public ReqEmployee storeDetails(List<EmployeeBean> eList) {
		return dao.storeDetails(eList);
		
	}

	@Override
	public List<Requisition> loadAll() {
		
		return dao.loadAll();
	}

	@Override
	public List<Requisition> loadAllPending() {
		
		return dao.loadAllPendings();
	}

	@Override
	public List<Requisition> loadAllClosed() {
		
		return dao.loadAllClosed();
	}

	@Override
	public void addEmployees(ReqEmployee req) {
		
		dao.addEmployees(req);
	}

	@Override
	public List<EmployeeBean> getAllDetails(String reqId, String rmId,String skill,String domain,
			EmployeeBean emp) {
		
		return dao.getAllDetails(reqId,rmId,skill,domain,emp);
	}

	
}
