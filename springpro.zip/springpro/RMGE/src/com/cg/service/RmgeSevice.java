package com.cg.service;

import java.util.List;

import com.cg.entity.EmployeeBean;
import com.cg.entity.ReqEmployee;
import com.cg.entity.Requisition;

public interface RmgeSevice {
	public abstract List<EmployeeBean> getDetails(Requisition req, EmployeeBean emp);

	public abstract ReqEmployee storeDetails(List<EmployeeBean> eList);

	public abstract List<Requisition> loadAll();

	public abstract List<Requisition> loadAllPending();

	public abstract List<Requisition> loadAllClosed();

	public abstract void addEmployees(ReqEmployee req);

	public abstract List<EmployeeBean>  getAllDetails(String reqId, String rmId,String skill,String domain,
			EmployeeBean emp);
}
