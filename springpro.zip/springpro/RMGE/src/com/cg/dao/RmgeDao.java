package com.cg.dao;

import java.util.List;

import com.cg.entity.EmployeeBean;
import com.cg.entity.ReqEmployee;
import com.cg.entity.Requisition;

public interface RmgeDao {

	List<EmployeeBean> getDetails(Requisition req, EmployeeBean emp);

	ReqEmployee storeDetails(List<EmployeeBean> eList);

	List<Requisition> loadAll();

	List<Requisition> loadAllPendings();

	List<Requisition> loadAllClosed();

	void addEmployees(ReqEmployee req);

	List<EmployeeBean> getAllDetails(String reqId, String rmId,String skill,String domain, EmployeeBean emp);

}
