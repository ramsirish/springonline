package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.EmployeeBean;
import com.cg.entity.ReqEmployee;
import com.cg.entity.Requisition;

@Repository
public class RmgeDaoImpl implements RmgeDao{
	@PersistenceContext
	private EntityManager entityManager;
	TypedQuery<EmployeeBean> query2;
	@Override
	public List<EmployeeBean> getDetails(Requisition req,EmployeeBean emp) {
		List<Requisition> requ=new ArrayList<Requisition>();
		String qtr="SELECT a FROM Requisition a WHERE a.requisitionId=:reqid and a.rmId=:rmid";
		TypedQuery<Requisition> query=	entityManager.createQuery(qtr,Requisition.class);
		query.setParameter("reqid", req.getRequisitionId());
		query.setParameter("rmid", req.getRmId());
		req = query.getSingleResult();
		if(req!=null)
		{
			String qStr="SELECT h FROM EmployeeBean h WHERE h.skill= :skill1 and h.domain= :domain1";
			query2=	entityManager.createQuery(qStr,EmployeeBean.class);
			query2.setParameter("skill1", req.getSkill());
			query2.setParameter("domain1", req.getDomain());
		}
		return query2.getResultList();
	}
	@Override
	public ReqEmployee storeDetails(List<EmployeeBean> eList) {
		entityManager.persist(eList);
		return null;
	}
	@Override
	public List<Requisition> loadAll() {
		String que="SELECT a FROM Requisition a";
		TypedQuery<Requisition> query=	entityManager.createQuery(que,Requisition.class);
		return query.getResultList();
	}
	@Override
	public List<Requisition> loadAllPendings() {
		String que="SELECT a FROM Requisition a WHERE a.currentStatus=:status";
		TypedQuery<Requisition> query=	entityManager.createQuery(que,Requisition.class);
		query.setParameter("status","pending");
		return query.getResultList();
		
	}
	@Override
	public List<Requisition> loadAllClosed() {
		String que="SELECT a FROM Requisition a WHERE a.currentStatus=:status";
		TypedQuery<Requisition> query=	entityManager.createQuery(que,Requisition.class);
		query.setParameter("status","closed");
		return query.getResultList();
	}
	@Override
	public void addEmployees(ReqEmployee req) {
		entityManager.persist(req);
		
	}
	@Override
	public List<EmployeeBean> getAllDetails(String reqId, String rmId,String skill,String domain,
			EmployeeBean emp) {
		List<Requisition> requ=new ArrayList<Requisition>();
		String qtr="SELECT a FROM Requisition a WHERE a.requisitionId=:reqid and a.rmId=:rmid";
		TypedQuery<Requisition> query=	entityManager.createQuery(qtr,Requisition.class);
		query.setParameter("reqid",reqId );
		query.setParameter("rmid", rmId);
		Requisition req = query.getSingleResult();
		if(req!=null){
			String qStr="SELECT h FROM EmployeeBean h WHERE h.skill= :skill1 and h.domain= :domain1";
			query2=	entityManager.createQuery(qStr,EmployeeBean.class);
			query2.setParameter("skill1", skill);
			query2.setParameter("domain1", domain);
		}
		return query2.getResultList();
	}

}
