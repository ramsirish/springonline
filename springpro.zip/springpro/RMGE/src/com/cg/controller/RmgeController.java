package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.EmployeeBean;
import com.cg.entity.ReqEmployee;
import com.cg.entity.Requisition;
import com.cg.service.RmgeSevice;

@Controller
public class RmgeController {
	Requisition reqObj=null;
@Autowired
private RmgeSevice service;
@RequestMapping("/index")
public String getHomePage(Model model){
	return "index";
}
private String requisitionId;
@RequestMapping("/rmge")
public String getPage(@ModelAttribute("rmg") Requisition requisition, Model model){
	String reqId=requisition.getRequisitionId();
	reqObj=new Requisition();
	this.requisitionId=reqId;
	model.addAttribute("rmg",reqObj);
	return "rmge";
}
/*
@RequestMapping(value="/rmreq",method=RequestMethod.POST)
public String add(@ModelAttribute("rmg") EmployeeBean emp ,Requisition req,Model model){
	
	    model.addAttribute("rmg",new EmployeeBean());
		model.addAttribute("rmg",new  Requisition());
		model.addAttribute("requisitionId",req.getRequisitionId());
        model.addAttribute("empList",service.getDetails(req,emp));
		return "rmreq";
	} */
@RequestMapping(value="/rmreq")
public String add(@RequestParam("reqId") String reqId,@RequestParam("rmId") String rmId,@RequestParam("skill") String skill,@RequestParam("domain") String domain,Model model,EmployeeBean emp){
	model.addAttribute("empList",service.getAllDetails(reqId,rmId,skill,domain,emp));
	service.getAllDetails(reqId,rmId,skill,domain,emp);
	return "rmreq";
}
@RequestMapping("/req")
public String getRequisitions(Model model){
	model.addAttribute("reqList",service.loadAll());
	model.addAttribute("req", new Requisition());
	return "req";
}
@RequestMapping("/pending")
public String getRequisitionsPending(Model model){
	model.addAttribute("reqPendingList",service.loadAllPending());
	model.addAttribute("req", new Requisition());
	return "pending";
}
@RequestMapping("/closed")
public String getRequisitionsClosed(Model model){
	model.addAttribute("reqClosedList",service.loadAllClosed());
	model.addAttribute("req", new Requisition());
	return "closed";
}
@RequestMapping(value="/employee")
public String sendRequisitions(@RequestParam("reqId") String requisitionId,@RequestParam("empId") String empId,@RequestParam("empName")
String empName,@RequestParam("empProjectId") String projectId,@RequestParam("empSkill") String skill,@RequestParam("empDomain") String domain,
@RequestParam("empExp") int exp,Model model){
	ReqEmployee req=new ReqEmployee();
	req.setReqId(requisitionId);
	req.setEmployeeId(empId);
	req.setName(empName);
	req.setProjectId(projectId);
	req.setSkill(skill);
	req.setDomain(domain);
	req.setExperience(exp);
	service.addEmployees(req);
	model.addAttribute("message","employee details sent successfully");
	return "empsuccess";
}
}
